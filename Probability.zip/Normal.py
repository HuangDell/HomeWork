from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D as Ax
import numpy as np
from scipy.stats import norm

class Normal:
    def __init__(self,rel):
        self.rel=rel
        self.div=0.05
        self.x=np.arange(-1,2,self.div)
        self.y=np.arange(-1,2,self.div)
        self.temp_x=None
        self.temp_y=None
        self.z=None
        self.zero_y=[2 for i in np.arange(-1,2,self.div)]
        self.zero_x=[-1 for i in np.arange(-1,2,self.div)]
        self.u1=0.3
        self.u2=0.5
        self.sigema1=0.3
        self.sigema2=0.5

    def randomTest(self):
        self.temp_x, self.temp_y=np.meshgrid(self.x,self.y)
        preix=1/(2*np.pi*self.sigema2*self.sigema1*np.sqrt(1-self.rel**2))
        suffix=np.exp((-1/(2*(1-self.rel**2)))*((((self.temp_x-self.u1)**2)/self.sigema1**2)-2*self.rel*((self.temp_x-self.u1)*(self.temp_y-self.u2)/(self.sigema2*self.sigema1))+((self.temp_y-self.u2)**2)/(self.sigema2**2)))
        self.z=preix*suffix
        pass

    def draw(self):
        self.randomTest()
        axis=plt.axes(projection='3d')
        axis.plot_surface(self.temp_x,self.temp_y,self.z, rstride=1, cstride=1, cmap="coolwarm")
        axis.plot(self.x,self.zero_y,norm.pdf(self.x,loc=self.u1,scale=self.sigema1),label="f(X)")
        axis.plot(self.x,self.zero_y,norm.cdf(self.x,loc=self.u1,scale=self.sigema1),label="F(X)",color="red")
        axis.plot(self.zero_x,self.y,norm.pdf(self.y,loc=self.u2,scale=self.sigema2),label="f(Y)",color="skyblue")
        axis.plot(self.zero_x,self.y,norm.cdf(self.y,loc=self.u2,scale=self.sigema2),label="F(Y)",color="limegreen")
        axis.set_xlabel('x')
        axis.set_ylabel('y')
        axis.set_zlabel('z')
        axis.legend()
        plt.show()

