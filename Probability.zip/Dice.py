from random import randint
from matplotlib import pyplot as plt

class Dice:
    def __init__(self,*tests):
        self.dice=[[0 for x in range(6)] for x in range(len(tests))]
        self.tests=tests
        self.x_data=[1,2,3,4,5,6]

    def randomTest(self):
        index=0
        for test in self.tests:
            for i in range(test):
                self.dice[index][randint(0,5)]+=1
            for i in range(6):
                self.dice[index][i]/=test
            index+=1

    def draw(self):
        self.randomTest()
        for i in range(len(self.tests)):
            plt.subplot(1,len(self.tests),i+1)
            plt.bar(x=self.x_data,height=self.dice[i])
            plt.title("n={}".format(self.tests[i]))
        plt.show()
