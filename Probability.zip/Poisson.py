import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import poisson
from scipy.stats import binom

class Poisson:
    def __init__(self,n,start=0,end=10):
        self.lamda=8
        self.n=n
        self.x=np.arange(start,end)
        self.poisson_y=[]
        self.bin_y=[]
        self.p=[]
        poisson.stats(self.lamda,moments="mvsk")
        for each_n in n:
            self.p.append(self.lamda/each_n)

    def randomTest(self):
        self.poisson_y=poisson.pmf(self.x,self.lamda)
        for i in range(len(self.n)):
            self.bin_y.append(binom.pmf(self.x,self.n[i],self.p[i]))


    def draw(self):
        self.randomTest()
        for i in range(len(self.n)):
            plt.subplot(1, len(self.n), i + 1)
            plt.plot(self.x,self.poisson_y,'x',linestyle='--',color="orange",label="Poisson")
            plt.plot(self.x,self.bin_y[i],'.',linestyle='-',color="deepskyblue",label="Binomial")
            plt.title("n={n},p={p}".format(n=self.n[i],p=self.p[i]))
            plt.legend()
        plt.show()



