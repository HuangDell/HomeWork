import Dice
import Normal
import Poisson

if __name__=="__main__":
    choose=input("Please enter a number to choose:\n1.Dice  2.Poisson && Binomial  3.Multivariate Normal\n")
    if choose=="1":
        dice=Dice.Dice(10,1000,100000)
        dice.draw()
    elif choose=="2":
        poisson=Poisson.Poisson([10,40,160],0,12)
        poisson.draw()
    else:
        normal=Normal.Normal(-0.9)
        normal.draw()